# Push-Ups counter > 2023-02-07 5:07pm
https://universe.roboflow.com/adrian-lachowicz/push-ups-counter

Provided by a Roboflow user
License: MIT

